#!/bin/sh
LD_PRELOAD=./libsandbox.so ./vuln
