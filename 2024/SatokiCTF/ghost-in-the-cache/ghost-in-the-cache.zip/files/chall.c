#define _GNU_SOURCE
#include <sched.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#ifdef _MSC_VER
#include <intrin.h> /* for rdtscp and clflush */
#pragma optimize("gt", on)
#else
#include <x86intrin.h> /* for rdtscp and clflush */
#endif

#define NAME_SIZE 0x10
#define PASS_SIZE 0x30
#define CACHE_SET_SIZE 0x100
#define CACHE_WAY_SIZE 0x2

typedef struct {
  uint8_t valid;
  uint64_t tag;
  char name[NAME_SIZE];
} CacheEntry;

typedef struct {
  CacheEntry entries[CACHE_WAY_SIZE] __attribute__((aligned(0x1000)));
} CacheSet;

CacheSet cache[CACHE_SET_SIZE] __attribute__((aligned(0x1000)));

char *satoki_pass;
char name_input[NAME_SIZE];
char pass_input[PASS_SIZE];

void menu() {
  puts("1. Put entry");
  puts("2. Put satoki");
  puts("3. Remove entry");
  puts("4. Reset");
  printf("> ");
}

void read_input(char *input_buffer, size_t buffer_size, const char *prompt) {
  printf("%s", prompt);
  for (size_t i = 0; i <= buffer_size; i++) {
    if (read(0, &input_buffer[i], 1) != 1) {
      perror("read");
      exit(1);
    }
    if (input_buffer[i] == '\n') {
      break;
    }
  }
  input_buffer[strcspn(input_buffer, "\n")] = '\0';
}

uint64_t hash(const char *name, const char *pass) {
  uint64_t hash_value = 0;
  for (size_t i = 0; i < NAME_SIZE; i++) {
    hash_value = (hash_value << 5) - hash_value + (uint8_t)name[i];
  }
  for (size_t i = 0; i < PASS_SIZE; i++) {
    hash_value = (hash_value << 5) - hash_value + (uint8_t)pass[i];
  }
  return hash_value;
}

size_t cache_set(char *pass) { return (unsigned char)pass[0]; }

void cache_lookup(char *name, char *pass, CacheEntry **hit_entry,
                  CacheEntry **empty_entry) {
  size_t set = cache_set(pass);
  uint64_t tag = hash(name, pass);
  uint32_t junk = 0;
  register uint64_t start, elapsed;

  _mm_mfence();
  _mm_lfence();
  start = __rdtscp(&junk); // Start timer
  for (int i = 0; i < CACHE_WAY_SIZE; i++) {
    if (cache[set].entries[i].valid == 1 && cache[set].entries[i].tag == tag) {
      *hit_entry = &cache[set].entries[i];
    } else if (cache[set].entries[i].valid == 0) {
      *empty_entry = &cache[set].entries[i];
    }
  }
  elapsed = __rdtscp(&junk) - start; // End timer and calculate elapsed time
  printf("Elapsed time for cache lookup: %lu\n", elapsed);
}

void put_entry(char *name, char *pass) {
  CacheEntry *hit_entry = NULL, *empty_entry = NULL;
  cache_lookup(name, pass, &hit_entry, &empty_entry);

  CacheEntry *entry = (hit_entry)     ? hit_entry
                      : (empty_entry) ? empty_entry
                                      : &cache[cache_set(pass)].entries[0];
  entry->valid = 1;
  entry->tag = hash(name, pass);
  memcpy(entry->name, name, NAME_SIZE);
}

void remove_entry(char *name, char *pass) {
  CacheEntry *hit_entry = NULL, *empty_entry = NULL;
  cache_lookup(name, pass, &hit_entry, &empty_entry);
  if (hit_entry) {
    hit_entry->valid = 0;
  }
}

void reset_cache() {
  for (int i = 0; i < CACHE_SET_SIZE; i++) {
    for (int j = 0; j < CACHE_WAY_SIZE; j++) {
      cache[i].entries[j].valid = 0;
    }
  }
  for (int i = 0; i < CACHE_SET_SIZE; i++) {
    for (int j = 0; j < CACHE_WAY_SIZE; j++) {
      _mm_clflush(&cache[i].entries[j]);
    }
  }
  _mm_mfence();
}

__attribute__((constructor)) void init() {
  setvbuf(stdin, NULL, _IONBF, 0);
  setvbuf(stdout, NULL, _IONBF, 0);
  alarm(2000);
}

void bind_core(int core) {
  cpu_set_t cpu_set;
  CPU_ZERO(&cpu_set);
  CPU_SET(core, &cpu_set);
  if (sched_setaffinity(getpid(), sizeof(cpu_set), &cpu_set) != 0) {
    perror("sched_setaffinity");
    exit(1);
  }
}

void init_satoki_pass() {
  if ((satoki_pass = malloc(PASS_SIZE)) == NULL) {
    perror("malloc");
    exit(1);
  }
  memset(satoki_pass, 0, PASS_SIZE);
  FILE *f = fopen("flag.txt", "r");
  if (f == NULL) {
    perror("fopen");
    exit(1);
  }
  if (fgets((char *)satoki_pass, PASS_SIZE - 1, f) == NULL) {
    perror("fgets");
    exit(1);
  }
  fclose(f);
}

int main() {
  bind_core(0);
  init_satoki_pass();

  while (1) {
    menu();
    int choice;
    if (scanf("%d", &choice) != 1) {
      perror("scanf");
      exit(1);
    }
    switch (choice) {
    case 1:
      read_input(name_input, NAME_SIZE, "Enter name: ");
      read_input(pass_input, PASS_SIZE, "Enter password: ");
      put_entry(name_input, pass_input);
      break;
    case 2:
      put_entry("satoki", satoki_pass);
      break;
    case 3:
      read_input(name_input, NAME_SIZE, "Enter name: ");
      read_input(pass_input, PASS_SIZE, "Enter password: ");
      remove_entry(name_input, pass_input);
      break;
    case 4:
      reset_cache();
      break;
    default:
      puts("Invalid choice");
      break;
    }
  }
  return 0;
}