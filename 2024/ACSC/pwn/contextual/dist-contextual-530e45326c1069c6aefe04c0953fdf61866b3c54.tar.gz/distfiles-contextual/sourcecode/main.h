#ifndef __MAIN_HEADER__
#define __MAIN_HEADER__

#include "util.h"
#include "vm.h"

#endif
