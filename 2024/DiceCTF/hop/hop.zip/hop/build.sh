#!/bin/sh

docker build -f Dockerfile.Build . -o out
