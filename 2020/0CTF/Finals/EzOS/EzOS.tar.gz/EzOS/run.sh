#!/bin/bash
cd `dirname $0`

elf="gzOS.elf"
flash="flash.bin"
initrd="initrd.cpio"

qemu-system-mips -machine malta \
		-cpu 4KEc \
		-m 128 \
		-bios none \
		-kernel $elf \
		-initrd $initrd \
		-display none \
        -pflash $flash \
		-serial null \
		-serial null \
        -serial stdio \
        -monitor /dev/null\
