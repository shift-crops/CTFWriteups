Hey, hackers!

Welcome to 0CTF/TCTF 2020 final, here is a baby stackoverflow challenge, real baby!

Flag stored in flash.bin, catch it!
