#!/bin/sh

docker build --no-cache -t rustymix .