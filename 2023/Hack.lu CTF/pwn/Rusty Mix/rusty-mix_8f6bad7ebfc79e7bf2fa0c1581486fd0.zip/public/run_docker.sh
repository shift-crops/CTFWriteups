#!/bin/sh

docker run --rm -i -t -p 4444:4444 rustymix