#!/bin/bash
docker build -t wacon_warmup . && docker run -p "80:80" --name wacon_warmup wacon_warmup