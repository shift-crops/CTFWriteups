#!/usr/bin/python3

from pwn import *

import random
import string
import base64
import subprocess
import os
import ast

context.log_level = 'error'

def randomString(length):
  characters = string.ascii_letters + string.digits
  result = ''.join(random.choice(characters) for i in range(length))
  return result

def checkValidCode(code):
  if not all(c in string.printable for c in code):
    return False

  for black in ['asm', '_', '#']:
    if black in code:
      return False
    
  return True

def checkValidBinary(tmpBinaryFile, tmpCodeFile):
  p = subprocess.Popen(['clang', '-o', tmpBinaryFile, tmpCodeFile, '-lseccomp'], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
  p.wait()
  if len(p.stderr.read()) != 0:
    return False
  
  elf = ELF(tmpBinaryFile)

  functions = list(elf.functions.keys())
  functions.sort()
  if functions != ['_start', 'main', 'menu', 'scan', 'scanInt', 'setup']:
    return False

  plt = list(elf.plt.keys())
  plt.sort()
  if plt != ['__cxa_finalize', 'exit', 'free', 'malloc', 'memset', 'printf', 'read', 'seccomp_init', 'seccomp_load', 'seccomp_release', 'seccomp_rule_add', 'setvbuf', 'strtoull', 'write']:
    return False

  p = subprocess.Popen(['seccomp-tools', 'dump', '-f', 'inspect', tmpBinaryFile], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
  p.wait()
  result = p.stdout.read().decode()
  result = ast.literal_eval(result)

  if result != "\x20\x00\x00\x00\x04\x00\x00\x00\x15\x00\x00\x13\x3E\x00\x00\xC0\x20\x00\x00\x00\x00\x00\x00\x00\x35\x00\x00\x01\x00\x00\x00\x40\x15\x00\x00\x10\xFF\xFF\xFF\xFF\x15\x00\x0E\x00\x00\x00\x00\x00\x15\x00\x0D\x00\x01\x00\x00\x00\x15\x00\x0C\x00\x02\x00\x00\x00\x15\x00\x0B\x00\x0F\x00\x00\x00\x15\x00\x0A\x00\x10\x00\x00\x00\x15\x00\x09\x00\x27\x00\x00\x00\x15\x00\x08\x00\x3C\x00\x00\x00\x15\x00\x07\x00\xE7\x00\x00\x00\x15\x00\x00\x07\x09\x00\x00\x00\x20\x00\x00\x00\x24\x00\x00\x00\x54\x00\x00\x00\x00\x00\x00\x00\x15\x00\x00\x04\x00\x00\x00\x00\x20\x00\x00\x00\x20\x00\x00\x00\x54\x00\x00\x00\x03\x00\x00\x00\x15\x00\x00\x01\x03\x00\x00\x00\x06\x00\x00\x00\x00\x00\xFF\x7F\x06\x00\x00\x00\x00\x00\x00\x00":
    return False

  return True

def checkSla(tmpBinaryFile, tmpCodeFile):
  p = subprocess.Popen(['clang', '-o', tmpBinaryFile, tmpCodeFile, '-lseccomp'], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
  p.wait()
  if len(p.stderr.read()) != 0:
    return False

  p = subprocess.Popen(['python3', 'sla.py', tmpBinaryFile], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
  if p.wait() == 255:
    return False
  return True

def checkVuln(tmpBinaryFile, tmpCodeFile):
  p = subprocess.Popen(['clang', '-o', tmpBinaryFile, tmpCodeFile, '-fsanitize=address', '-lseccomp'], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
  p.wait()
  if len(p.stderr.read()) != 0:
    return False

  p = subprocess.Popen(['python3', 'vuln.py', tmpBinaryFile], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
  p.wait()
  if len(p.stderr.read()) != 0:
    return False
  result = p.stdout.read()
  if b'AddressSanitizer: heap-use-after-free' not in result:
    return False
  return True

def checkExploit(tmpBinaryFile, tmpCodeFile):
  p = subprocess.Popen(['clang', '-o', tmpBinaryFile, tmpCodeFile, '-lseccomp'], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
  p.wait()
  if len(p.stderr.read()) != 0:
    return False
  
  tmpCheckFile = '/tmp/' + randomString(32)
  tmpCheckString = randomString(0x100)

  f = open(tmpCheckFile, 'w')
  f.write(tmpCheckString)
  f.close()

  p = subprocess.Popen(['python3', 'ex.py', tmpBinaryFile, tmpCheckFile], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
  p.wait()
  result = p.stdout.read()
  result = result.decode()[:-1]
  os.unlink(tmpCheckFile)
  if tmpCheckString not in result:
    return False

  return True

print('End of your code __EOF__')
code = ''
while True:
  c = input()
  if '__EOF__' in c:
    break
  code += c + '\n'

if not checkValidCode(code):
  print('This is not my challenge...')
  exit(1)

tmpBinaryFile = '/tmp/' + randomString(16)
tmpCodeFile = '/tmp/' + randomString(16) + '.c'

t = open('./skeleton.c', 'r')
template = t.read()
t.close()

f = open(tmpCodeFile, 'w')
f.write(template + code)
f.close()

checks = [checkValidBinary, checkSla, checkVuln, checkExploit]
for check in checks:
  if not check(tmpBinaryFile, tmpCodeFile):
    if os.path.exists(tmpBinaryFile): os.unlink(tmpBinaryFile)
    print('This is not my challenge...')
    print(check)
    exit(1)
  if os.path.exists(tmpBinaryFile): os.unlink(tmpBinaryFile)


print('Good! This is my challenge :)')
print('WACON2023{EXAMPLE_FLAG}')

os.unlink(tmpCodeFile)