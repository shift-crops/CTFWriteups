#!/bin/sh

cd /home/ctf
./check.py