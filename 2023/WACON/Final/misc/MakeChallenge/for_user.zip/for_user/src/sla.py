from pwn import *
import sys

def add(p, idx, size):
  p.sendafter(b':> ', '1'.encode())
  p.sendafter(b':> ', str(idx).encode())
  p.sendafter(b':> ', str(size).encode())

def edit(p, idx, data):
  p.sendafter(b':> ', '2'.encode())
  p.sendafter(b':> ', str(idx).encode())
  p.sendafter(b':> ', data)

def view(p, idx):
  p.sendafter(b':> ', '3'.encode())
  p.sendafter(b':> ', str(idx).encode())

def delete(p, idx):
  p.sendafter(b':> ', '4'.encode())
  p.sendafter(b':> ', str(idx).encode())


def sla1(proc):
  p = process(proc)
  add(p, 0, 0x100)
  view(p, 0)
  d = p.recv(0x100)
  p.close()
  if len(d) != 0x100 or d != b'\x00'*0x100:
    return False
  return True

def sla2(proc):
  p = process(proc)
  add(p, 0, 10)
  edit(p, 0, b'slaTesting')
  view(p, 0)
  d = p.recv(10)
  p.close()
  if len(d) != 10 or d != b'slaTesting':
    return False
  return True


def sla3(proc):
  p = process(proc)
  add(p, 0, 10)
  add(p, 2, 10)
  edit(p, 0, b'slaTestin1')
  edit(p, 2, b'slaTestin2')
  view(p, 0)
  d1 = p.recv(10)
  view(p, 2)
  d2 = p.recv(10)
  p.close()
  if len(d1) != 10 or d1 != b'slaTestin1' or len(d2) != 10 or d2 != b'slaTestin2':
    return False
  return True

def sla4(proc):
  p = process(proc)
  add(p, 0, 10)
  delete(p, 0)
  add(p, 0, 10)
  edit(p, 0, b'slaTesting')
  view(p, 0)
  d = p.recv(10)
  p.close()
  if len(d) != 10 or d != b'slaTesting':
    return False
  return True

if len(sys.argv) != 2:
  print('python3 sla.py [execute path]')
  exit(1)

context.log_level = 'error'

tests = [sla1, sla2, sla3, sla4]
for test in tests:
  result = test(sys.argv[1])
  if result == False:
    exit(-1)

exit(1)