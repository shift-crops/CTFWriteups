#include <stdio.h>
#include <inttypes.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>
#include <unistd.h>
#include <seccomp.h>
#include <linux/seccomp.h>
#include <unistd.h>
#include <sys/mman.h>
#include <stdlib.h>

int __attribute__((constructor)) setup()
{
    setvbuf(stdin, 0, 2, 0);
    setvbuf(stdout, 0, 2, 0);

    scmp_filter_ctx ctx = seccomp_init(SCMP_ACT_KILL);
    if (ctx == NULL)
    {
        printf("seccomp_init failed\n");
        return 1;
    }

    if (seccomp_rule_add(ctx, SCMP_ACT_ALLOW, SCMP_SYS(open), 0) < 0 ||
        seccomp_rule_add(ctx, SCMP_ACT_ALLOW, SCMP_SYS(read), 0) < 0 ||
        seccomp_rule_add(ctx, SCMP_ACT_ALLOW, SCMP_SYS(write), 0) < 0 ||
        seccomp_rule_add(ctx, SCMP_ACT_ALLOW, SCMP_SYS(exit), 0) < 0 ||
        seccomp_rule_add(ctx, SCMP_ACT_ALLOW, SCMP_SYS(rt_sigreturn), 0) < 0 ||
        seccomp_rule_add(ctx, SCMP_ACT_ALLOW, SCMP_SYS(ioctl), 0) < 0 ||
        seccomp_rule_add(ctx, SCMP_ACT_ALLOW, SCMP_SYS(getpid), 0) < 0 ||
        seccomp_rule_add(ctx, SCMP_ACT_ALLOW, SCMP_SYS(exit_group), 0) < 0)
    {
        printf("seccomp_rule_add failed\n");
        return 1;
    }

    if (seccomp_rule_add(ctx, SCMP_ACT_ALLOW, SCMP_SYS(mmap), 1,
                         SCMP_A2(SCMP_CMP_MASKED_EQ, PROT_READ | PROT_WRITE, PROT_READ | PROT_WRITE)) < 0)
    {
        printf("seccomp_rule_add failed for mmap\n");
        return -1;
    }

    if (seccomp_load(ctx) < 0)
    {
        printf("seccomp_load failed\n");
        return 1;
    }

    seccomp_release(ctx);
    return 0;
}

// IMPLEMENT
