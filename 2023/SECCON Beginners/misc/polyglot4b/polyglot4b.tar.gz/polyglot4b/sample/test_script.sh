#!/bin/bash
file sushi.jpg
cat sushi.jpg | nc localhost 31416