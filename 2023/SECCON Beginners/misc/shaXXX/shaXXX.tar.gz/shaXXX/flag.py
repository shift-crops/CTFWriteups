# top secret (- __ -)
flag = b"ctf4b{dummy_flag}"
