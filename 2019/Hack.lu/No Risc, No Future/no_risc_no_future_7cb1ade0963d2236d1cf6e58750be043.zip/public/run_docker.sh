#!/bin/bash
docker run --rm -t -p 1338:1338 --name no_risc_no_future no_risc_no_future