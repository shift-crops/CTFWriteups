#!/bin/bash
docker build -t no_risc_no_future:latest -f Dockerfile .