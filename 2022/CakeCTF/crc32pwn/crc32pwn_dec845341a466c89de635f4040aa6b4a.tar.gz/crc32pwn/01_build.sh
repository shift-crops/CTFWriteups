#!/bin/sh
docker build . -t crc32pwn
